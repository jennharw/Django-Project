from . import api
from flask import jsonify
from flask import request
import requests 

@api.route('/todos', methods = ['GET', 'POST'])
def todos():
    if request.method == "POST":
        res = requests.post('https://hooks.slack.com/services/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',json={
            'text':'Hi Harim'
        }, headers = {'Content-Type':'application/json'})
    else:
        pass
    data = request.get_json()
    return jsonify(data)

@api.route('/test', methods = ['POST'])
def test():
    res = request.form['text']
    print(res)
    return jsonify(res)